# Digital Voice Modem Host

- Bryan Biedenkapp (https://github.com/gatekeep)
- Natalie Moore (https://github.com/jelimoore)

- Build Chain and Helper Tools
  - K4YT3X (https://github.com/k4yt3x)

- Documentation Team
  - Charles Bricker (https://github.com/ceb515)
  - Connor Lovell (https://github.com/DevRanger)

- Community Support Team
  - Steven Jennison (https://github.com/sjennison)
  - Charles Bricker (https://github.com/ceb515)

## Special thanks to

- Jonathan Naylor G4KLX (https://github.com/g4klx) and the MMDVM authors.
